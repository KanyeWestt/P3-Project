package VirtualPet;

import Pet.Cat;
import Pet.Dog;
import Pet.Pet;
import javax.swing.*; // Needed for JFrame
import java.awt.event.*; // Need soon for ActionListener
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.*; // Need soon for ListSelectionListener, DocumentListener
import java.util.Scanner;

import java.awt.Color;
import java.awt.Font;

/**
 * 
 * @author Mark Lanthier
 * @see <a href=
 *      "http://people.scs.carleton.ca/~lanthier/teaching/COMP1406/Notes/Code/Chapter6/">
 *      GroceryListApplication</a>
 *
 */
public class VirtualPetApp extends JFrame 
{
    private User userlist;
    private Pet pet;
    UserDB userDB = new UserDB();

    Scanner scanner = new Scanner(System.in);
    
	private ItemList model; // The model to which this view is attached
	private PetView view; // The view that shows the state of the model

	public VirtualPetApp(String title) 
	{
		super(title); // Sets the title of the window

		// Create the model and view
		model = new ItemList();
		view = new PetView(model);

		// Add the view
		getContentPane().add(view);

		view.getAddButton().addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) {
				handleAddButtonPress();
			}
		});

//		view.getRemoveButton().addActionListener(new ActionListener() 
//		{
//			public void actionPerformed(ActionEvent e) 
//			{
//				handleRemoveButtonPress();
//			}
//		});



		view.getStatsBoxField().getDocument().addDocumentListener(new DocumentListener() {
			public void changedUpdate(DocumentEvent theEvent)
			{
				handleTextEntry();
			}

			public void insertUpdate(DocumentEvent theEvent)
			{
				handleTextEntry();
			}

			public void removeUpdate(DocumentEvent theEvent)
			{
				handleTextEntry();
			}
		});

		// Manually computed size
		setSize(750, 500);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	// The Add Button event handler
	private void handleAddButtonPress() 
	{
		String text = view.getStatsBoxField().getText().trim();
		if (text.length() > 0) {
			view.getStatsBoxField().setText("");
			model.add(text);
			view.update();
		}
	}

	// The Remove Button event handler
//	private void handleRemoveButtonPress() 
//	{
//		int index = view.getList().getSelectedIndex();
//		if (index >= 0) {
//			model.remove(index);
//			view.update();
//		}
//	}

	// The List click event handler
	private void handleListSelection() 
	{
		view.update();
	}

	// The text field typing event handler
	private void handleTextEntry() 
	{
		view.update();
	}       
        /**
     * This method displays the status of the pet
     */
    public void displayStats() {
        System.out.println(pet.toString());
    }

    /**
     * This method obtains any existing users from the user list
     */
    public VirtualPetApp() {
        this.userlist = new User();

        //userDB.getQuery(userlist);
        //ReadUserDataFile.ReadUserFile(userlist);
    }

    /**
     * This method will update the user data
     */
    public void updataUser() {
        // userDB.createTable(userlist);
        //ReadUserDataFile.writeToFile(userlist);
    }

    /**
     * This method will check for error from user input and prompt them to press
     * the right one
     *
     * @param stringInput
     * @return
     */
    public int errorValidation(String stringInput) {
        Integer integerInput = null;

        boolean checkValue = false;

        while (!checkValue) {
            try {
                stringInput = scanner.next();

                integerInput = Integer.parseInt(stringInput);
                checkValue = true;

            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please enter the right value.");

            }
        }
        return integerInput;
    }

    /**
     * This method is primarily used to choose between a dog and a cat object to
     * be created without error
     *
     * @param input
     * @return
     */
    public int rangeCheck(String input) {
        int num;

        while (true) {
            num = errorValidation(input);

            if (num < 1 || num > 2) {
                System.out.println("Invalid selection. Enter 1 or 2 only.");

            } else {
                return num;
            }
        }
    }

    /**
     * This method will help the user to understand the game which can be called
     * anytime while they're playing
     */
    public void help() {
        System.out.println("\nHow to play the game: "
                + "\nYou will become a proud owner of a pet."
                + " \nYou must first choose your type of pet between a cat or a dog."
                + "\nYou can interact with your pet 3 times a day until they need to rest."
                + "\nMake sure they are healthy!"
                + "\nHave fun with your new pet!\n ");
    }

    /**
     * This method will check an existing user from the user list file
     *
     * @return
     */
    public String checkUser() {

        System.out.println("Hello, what is your name?");
        String userName = scanner.nextLine();
        System.out.println("Nice to meet you " + userName + "!");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        userName = userName.substring(0, 1).toUpperCase() + userName.substring(1).toLowerCase();

        if (userlist.containsUser(userName)) {
            pet = userlist.getPet(userName);
        } else {
            createNewUser();
        }
        return userName;
    }

    public void createNewUser() {
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Give your new pet a name!");
        String petName = scanner.nextLine();

        System.out.println("Please select an animal to adopt [Press 1 for dog or 2 for cat.");
        int petSelection = rangeCheck(petName);

        if (petSelection == 1) {
            pet = new Dog(petName);
            System.out.println("You chose a dog!");
        } else if (petSelection == 2) {
            pet = new Cat(petName);
            System.out.println("You chose a cat!");
        }
    }

    /**
     * This method will prompt the user to choose an action and allows the game
     * to continue
     *
     * @param userName
     */
    public void action(String userName) {

        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Hello " + userName + ".");
        System.out.println("Your pet " + pet.getName() + " is happy to see you.");
        //Everytime a new user is created, it will store the pet name to that username and call it from file next time.
        ReadUserDataFile.writeToFile(userlist);

        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("What would you like to do with " + pet.getName() + " today?");
        boolean notDone = true;
        while (notDone) {
            notDone = gamePlay(userName);
        }
        System.out.println("\n\tThank you for playing!");

    }

    /**
     * This method allows the user to interact with their pet 3 times a day.
     * Every action will decrease actionsPerdDay and once they've done 3 actions
     * It will then increase the dayCount variable by 1
     *
     * @param userName
     * @return boolean
     */
    public boolean gamePlay(String userName) {
        //Game begins:
        int actionsPerDay = 3;
        System.out.println("Please select a number (You have three actions per day): \n1. Feed \n2. Walk \n3. Pet \n4. Rest \n9.[Help!]\n0 [To exit.]");

        while (actionsPerDay != 0) {

            System.out.print("Your choice: ");
            // int userActionChoice = scanner.nextInt();
            String input = scanner.nextLine();

            int value = errorValidation(input);

            switch (value) {
                case 0:
                    return false;

                case 1:
                    pet.feed();
                    actionsPerDay--;
                    displayStats();
                    break;

                case 2:
                    pet.walk();
                    actionsPerDay--;
                    displayStats();
                    break;

                case 3:
                    pet.pet();
                    actionsPerDay--;
                    displayStats();
                    break;

                case 4:
                    pet.rest();
                    actionsPerDay--;
                    displayStats();
                    break;

                case 9:
                    help();
                    break;
                default:
                    System.out.println("Invalid option. Please choose again.");

                    break;

            }
            if (actionsPerDay == 0) {
                System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
                pet.sleep();
                System.out.println("A new day is dawning...");

                try {
                    TimeUnit.SECONDS.sleep(2);
                    System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
                } catch (InterruptedException ex) {
                    Logger.getLogger(VirtualPetApp.class.getName()).log(Level.SEVERE, null, ex);
                }
                pet.addDayCount();
                System.out.println("Day: " + pet.getDayCount());
                displayStats();
            }
            if (pet.checkStats()) {
                System.out.println(pet.getName() + " ran away from home...");
                System.out.println(pet.getName() + " You're a bad pet owner!");
                userlist.removeUser(userName);
                return false;

            }
            userlist.addUser(userName, pet);

        }
        return true;
    }

    /**
     * This is the main method. It creates new objects of different classes. It
     * handles methods from its own body. It also handles the user list file and
     * runs the game overall.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VirtualPetApp frame;

        frame = new VirtualPetApp("Virtual Pet Game");
        frame.setVisible(true);

        //System.out.println(userList.getPet("nefwgu").getExcitement());

       // System.out.println("whw" + userList.getUserList());
        // user.createTable();
        //VirtualPetApp app = new VirtualPetApp();
        //app.action(app.checkUser());
        //app.updataUser();

    }

}