/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import Pet.Pet;
import Pet.Dog;
import Pet.Cat;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author phaisan
 */
public class UserDB {

    public Connection connection = null;

    public String url = "jdbc:derby:UserDB;create=true";  //url of the DB host
    public String usernameDerby = "admin";  //your DB usernameDerby
    public String passwordDerby = "1234";   //your DB passwordDerby

    public String tableName = "UserDB";
    public Statement statement;
    public ResultSet resultSet;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public UserDB() {
        establishConnection();
    }

    public void establishConnection() {
        try {
            connection = DriverManager.getConnection(url, usernameDerby, passwordDerby);
            System.out.println(url + "   connected....");
            statement = connection.createStatement();

        } catch (SQLException ex) {
            Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void createTable() {
        try {
            if (checkTableExisting(tableName)) {
                delectTable(tableName);
            }
            String sqlCreate = "create table " + tableName
                    + "(userName varchar(30), petType varchar(10),petName varchar(30),  "
                    + "fullness int, energy int, excitment int, dayCount int)";
            statement.executeUpdate(sqlCreate);
            System.out.println("Table created");

        } catch (SQLException ex) {
            Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insertTable(User userList) {
        userList.getUserList().entrySet().forEach((Map.Entry<String, Pet> list) -> {
            try {
                String sqlInsert = "insert into " + tableName.toUpperCase() + " values("
                        + "'" + list.getKey() + "', '"
                        + list.getValue().getClass().getSimpleName().toLowerCase() + "', '"
                        + list.getValue().getName().toLowerCase() + "', "
                        + list.getValue().getFullness() + ", "
                        + list.getValue().getEnergy() + ", "
                        + list.getValue().getExcitement() + ", "
                        + list.getValue().getDayCount() + ")";
                System.out.println(sqlInsert);
                statement.executeUpdate(sqlInsert);
            } catch (SQLException ex) {
                Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }

    public void getQuery(User userList) {
        Pet pet;
        try {
            System.out.println(" getting query....");

            String sqlQuery = "select * from " + this.tableName;
            resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                String userName = resultSet.getString(1).trim().toLowerCase();
                String petType = resultSet.getString(2).trim().toLowerCase();
                String petName = resultSet.getString(3).trim().toLowerCase();
                int fullness = resultSet.getInt(4);
                int energy = resultSet.getInt(5);
                int excitment = resultSet.getInt(6);
                int dayCount = resultSet.getInt(7);
                switch (petType) {
                    case "dog":
                        pet = new Dog(petName, fullness, energy, excitment, dayCount);
                        userList.addUser(userName, pet);
                    case "cat":
                        pet = new Cat(petName, fullness, energy, excitment, dayCount);
                        userList.addUser(userName, pet);
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void delectTable(String tableName) throws SQLException {
        System.out.println(tableName + "  needs to be deleted");
        String sqlDropTable = "DROP TABLE " + tableName;
        this.statement.executeUpdate(sqlDropTable);
        System.out.println(tableName + " table deleted");

    }

    private boolean checkTableExisting(String tableName) throws SQLException {

        System.out.println("check existing tables.... ");
        this.resultSet = connection.getMetaData().getTables(null, null, null, null);//types);
        // Statement dropStatement = null;

        while (this.resultSet.next()) {
            String table = this.resultSet.getString("TABLE_NAME");
            if (table.compareToIgnoreCase(tableName) == 0) {
                return true;
            }
        }

        return false;

    }

    public void closeConnections() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}

/*public void createTable() {
try {
checkTableExisting(tableName);
String sqlCreate = "create table " + tableName
+ "(userName varchar(30), petType varchar(10),petName varchar(30),  "
+ "fullness int, energy int, excitment int, dayCount int)";
statement.executeUpdate(sqlCreate);
System.out.println("Table created");

} catch (SQLException ex) {
Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
}
}

public void updataTable(String userName, Pet pet) {
try {
String sqlUpdateTable = "update " + tableName + " set "
+ "petType = '" + pet.getClass().getSimpleName() + "',"
+ "petName = '" + pet.getName() + "',"
//--------------------------------------------
+ "fullness = " + pet.getFullness() + ","
+ "energy = " + pet.getEnergy() + ","
+ "excitment = " + pet.getExcitement() + ","
+ "dayCount = " + pet.getDayCount() + ""
//--------------------------------------------
+ "where userName='" + userName + "'";
statement.executeUpdate(sqlUpdateTable);

} catch (SQLException ex) {
Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
}
}

public void insertTable(String userName, Pet pet) {
try {
String sqlInsert = "insert into " + tableName + " values("
+ "'" + userName + "', '"
+ pet.getClass().getSimpleName() + "', '"
+ pet.getName() + "', "
+ pet.getFullness() + ", "
+ pet.getEnergy() + ", "
+ pet.getExcitement() + ", "
+ pet.getDayCount() + ", )";

statement.executeUpdate(sqlInsert);
} catch (SQLException ex) {
Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
}
}

public Pet getUserData(String userName) {
Pet pet = null;
try {
System.out.println(" getting query....");

String sqlQuery = "select * from car  "
+ "where userName='" + userName + "'";
resultSet = statement.executeQuery(sqlQuery);

if (resultSet.next()) {
String usernameDerby = resultSet.getString(1);
String petType = resultSet.getString(2);
String petName = resultSet.getString(3);
int fullness = resultSet.getInt(4);
int energy = resultSet.getInt(5);
int excitment = resultSet.getInt(6);
int dayCount = resultSet.getInt(7);

switch (petType.toLowerCase()) {
case "dog":
return new Dog(petName, fullness, energy, excitment, dayCount);
case "cat":
return new Cat(petName, fullness, energy, excitment, dayCount);
}
}

} catch (SQLException ex) {
Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
}

//return(resultSet);
return pet;
}*/
