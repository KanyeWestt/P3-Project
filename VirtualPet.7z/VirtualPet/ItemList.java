/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author gsj6766
 */
public class ItemList {
	public final int MAXIMUM_SIZE = 100;

	private String[] items;
	private int size;

	public ItemList() {
		items = new String[MAXIMUM_SIZE];
		size = 0;
	}

	public int getSize() {
		return size;
	}

	public String[] getItems() {
		return items;
	}

	public void add(String item) {
		// Make sure that we do not go past the limit
		if (size < MAXIMUM_SIZE)
			items[size++] = item;
	}

	public void remove(int index) {
		// Make sure that the given index is valid
		if ((index >= 0) && (index < size)) {
			// Move every item after the deleted one up in the list
			for (int i = index; i < size; i++)
				items[i] = items[i + 1];
			size--; // Reduce the list size by 1
		}
	}
}