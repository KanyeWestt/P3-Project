/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

/**
 *
 * @author phaisan
 */
public class PetView extends JPanel implements Observer {

    private ItemList model; // The model to which this view is attached

    // The user interface components needed by the controller
    private JList aList;
    private JButton addButton;
    private JButton removeButton;
    private JButton feedButton;
    private JButton walkButton;
    private JPanel image;

    private JTextField statsBoxField;
    private JTextField dialogueBox;

    // public methods to allow access to JComponents
    public JButton getAddButton() {
        return addButton;
    }

    public JButton getRemoveButton() {
        return removeButton;
    }

    public JButton getFeedButton() {
        return feedButton;
    }

    public JButton getWalkButton() {
        return walkButton;
    }

    public JTextField getStatsBoxField() {
        return statsBoxField;
    }

    public JTextField dialgoueBoxField() {
        return dialogueBox;
    }

    public PetView(ItemList model) {
        this.model = model; // Store the model for access later

        // Choose to lay out components manually
        setLayout(null);

        // Add the text field
        statsBoxField = new JTextField();
        statsBoxField.setLocation(700, 200);
        statsBoxField.setSize(150, 150);
        add(statsBoxField);

        // Add the text field
        dialogueBox = new JTextField();
        dialogueBox.setLocation(125, 500);
        dialogueBox.setSize(600, 70);
        add(dialogueBox);

        // Add the ADD button
        addButton = new JButton("Add");
        addButton.setLocation(10, 150);
        addButton.setSize(100, 25);
        add(addButton);

        // Add the REMOVE button
        removeButton = new JButton("Remove");
        removeButton.setLocation(10, 210);
        removeButton.setSize(100, 25);
        add(removeButton);

        // Add the ADD button
        addButton = new JButton("Feed");
        addButton.setLocation(10, 270);
        addButton.setSize(100, 25);
        add(addButton);

        // Add the ADD button
        addButton = new JButton("Walk");
        addButton.setLocation(10, 330);
        addButton.setSize(100, 25);
        add(addButton);

        JPanel catPanel = new JPanel();
        ImageIcon catImage = new ImageIcon(getClass().getResource("cat.jpg"));
        //JPanel.add(image, BorderLayout.NORTH);
        catPanel.add(new JLabel(catImage), BorderLayout.CENTER);
        catPanel.setPreferredSize(new Dimension(300, 300));
        catPanel.setSize(325, 350);
        catPanel.setLocation(265, 150);
        add(catPanel);

        setSize(290, 230); // manually computed sizes

        // Call update() to make sure model contents are shown
    }

    // Update the view to show the model's state
//	public void update() {
//		// Remember what was selected
//		int selectedItem = aList.getSelectedIndex();
//
//		// Now re-populate the list
//		String[] exactList = new String[model.getSize()];
//		for (int i = 0; i < model.getSize(); i++)
//			exactList[i] = model.getItems()[i];
//		aList.setListData(exactList);
//
//		// Reselect the selected item
//		aList.setSelectedIndex(selectedItem);
//                
//                //Fix this
//		removeButton.setEnabled(aList.getSelectedIndex() >= 0);
//		addButton.setEnabled(statsBoxField.getText().trim().length() > 0);
//	}
    @Override
    public void update(Observable o, Object arg) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     *
     * @author Mark Lanthier
     * @see <a href=
     *      "http://people.scs.carleton.ca/~lanthier/teaching/COMP1406/Notes/Code/Chapter6/">
     * GroceryListView</a>
     *
     */
}
