/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author gsj6766
 */
public class VirtualPetApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        long timer = System.currentTimeMillis();
        long second = (timer / (1000 * 60));
        long minute = (timer / (1000 * 60)) % 60;
        long hour = (timer / (1000 * 60 * 60)) % 24;
        String time = String.format("%02d:%02d:%02d", hour, minute, second);

        System.out.println(time);        // TODO code application logic here
    }

}
