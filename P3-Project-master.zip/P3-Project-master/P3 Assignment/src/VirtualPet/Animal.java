/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author gsj6766
 */
public  abstract class Animal {
    protected int fullness;
    protected int energy;
    protected int excitement;
    protected int happiness;
    protected String name;
    protected long time = System.currentTimeMillis();
    
    public void walk() {
        this.excitement ++;
        this.energy--;
        this.fullness--;
    }
    
    public void feed(){
        this.fullness ++;
        this.energy ++;
        this.excitement --;
    }
    
    public void rest(){
        this.fullness --;
        this.energy ++;
        this.excitement --;
    }
    
    public void pet(){
        this.fullness --;
        this.excitement++;
    }
    
    public void sleep(){
        this.fullness --;
        this.excitement --;
        this.energy ++;
    }
    
    
    
    
    
    
    
}
