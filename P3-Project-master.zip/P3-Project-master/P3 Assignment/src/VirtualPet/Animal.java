/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author gsj6766
 */
public  abstract class Animal {
    protected int fullness;
    protected int energy;
    protected int excitement;
    protected int happiness;
    protected String name;
    protected long time = System.currentTimeMillis();

    public Animal() {
        this.fullness = 0;
        this.energy = 0;
        this.excitement = 0;
        this.happiness = 0;
    }
    
    public Animal(String name) {
        this.name = name;
    }
    
    public void walk() {
        this.excitement ++;
        this.energy--;
        this.fullness--;
    }
    
    public void feed(){
        this.fullness ++;
        this.energy ++;
        this.excitement --;
    }
    
    
    
    
    
    
}
