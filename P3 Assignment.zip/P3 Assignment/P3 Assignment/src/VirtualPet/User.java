/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.HashMap;

/**
 *
 * @author Phaisan & Shannon
 */
public class User {

    private HashMap<String, Pet> userList;

    public User() {
        this.userList = new HashMap<String, Pet>();
    }

    public HashMap<String, Pet> getUserList() {
        return userList;
    }

    public void addUser(String userName, Pet animal) {
        this.userList.put(userName.toLowerCase(), animal);
    }

    public void removeUser(String userName) {
        this.userList.remove(userName.toLowerCase());
    }

    public void clear() {
        this.userList.clear();
    }

    public boolean containsUser(String petName) {
        if (this.userList.containsKey(petName.toLowerCase())) {
            return true;
        } else {
            System.out.println("\tNew user");
            return false;
        }
    }

    public Pet getPet(String userName) {
        return this.userList.get(userName.toLowerCase());
    }

}
