/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Phaisan & Shannon
 */
public class VirtualPetApp {

    private User user;

    public VirtualPetApp(User user, Pet pet) {
        this.user = new User();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User userlist = new User();
        ReadUserDataFile.ReadUserFile(userlist);

        System.out.println("Hello, what is your name?");
        String userName = scanner.nextLine();
        Pet pet = userlist.getPet(userName);

        System.out.println("Give your new pet a name!");
        String petName = scanner.nextLine();

        System.out.println("Please select an animal to adopt [Press 1 for dog or 2 for cat.");
        int petSelection = scanner.nextInt();

        if (petSelection == 1) {
            userlist.addUser(userName, new Dog(petName));
            System.out.println("You chose a dog!");
        } else if (petSelection == 2) {
            userlist.addUser(userName, new Cat(petName));
            System.out.println("You chose a cat!");
        }
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Hello '" + userName + "'.");
        System.out.println("Your pet '" + userlist.getPet(petName) + "' is *insert mood* to see you.");
        //Everytime a new user is created, it will store the pet name to that username and call it from file next time.
        ReadUserDataFile.writeToFile(userlist);

        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("What would you like to do with " + userlist.getPet(petName) + " today?");

        //Game begins:
        int actionsPerDay = 3;
        while (actionsPerDay != 0) {
            System.out.println("Please select a number (You have three actions per day): \n1. Feed \n2. Walk \n3. Pet \n4. Rest \n5. Sleep");
            System.out.print("Your choice: ");
            int userActionChoice = scanner.nextInt();

            switch (userActionChoice) {
                case 1:
                    pet.feed();
                    actionsPerDay--;
                    break;
                    
                case 2:
                    pet.walk();
                    actionsPerDay--;
                    break;

                case 3:
                    pet.pet();
                    actionsPerDay--;
                    break;

                case 4:
                    pet.rest();
                    actionsPerDay--;
                    break;

                case 5:
                    pet.sleep();
                    actionsPerDay--;
                    break;

                default:
                    System.out.println("Invalid option. Please choose again.");
                    break;

            }
        }
        /*long timer = System.currentTimeMillis();
        long second = (timer / (1000 * 60));
        long minute = (timer / (1000 * 60)) % 60;
        long hour = (timer / (1000 * 60 * 60)) % 24;
        String time = String.format("%02d:%02d:%02d", hour, minute, second);*/
 /*Map<String,Integer> m = new  HashMap<String,Integer>();
        
        m.put("a", 1);
        m.put("b", 2);
        m.put("c", 3);
        m.put("d", 3);
        m.put("f", 3);
        
        for(Map.Entry<String,Integer> item : m.entrySet())
        System.out.println(item.getKey()+" "+item.getValue() );
         */
    }

// public final static void clearConsole()
//{
//    try
//    {
//        final String os = System.getProperty("os.name");
//
//        if (os.contains("Windows"))
//        {
//            Runtime.getRuntime().exec("cls");
//        }
//        else
//        {
//            Runtime.getRuntime().exec("clear");
//        }
//    }
//    catch (final Exception e)
//    {
//        //  Handle any exceptions.
//    }
}
