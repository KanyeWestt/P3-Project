/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Phaisan & Shannon
 */
public class VirtualPetApp {

    private User userlist;
    private Pet pet;

    Scanner scanner = new Scanner(System.in);

    public void displayStats() {
        System.out.println(pet.toString());

    }

    public VirtualPetApp() {
        this.userlist = new User();
        ReadUserDataFile.ReadUserFile(userlist);
    }

    public void updataUser() {
        ReadUserDataFile.writeToFile(userlist);
    }

    public String checkUser() {

        System.out.println("Hello, what is your name?");
        String userName = scanner.nextLine();
        userName = userName.substring(0, 1).toUpperCase() + userName.substring(1).toLowerCase();

        if (userlist.containsUser(userName)) {
            pet = userlist.getPet(userName);
        } else {
            System.out.println("Give your new pet a name!");
            String petName = scanner.nextLine();

            System.out.println("Please select an animal to adopt [Press 1 for dog or 2 for cat.");
            int petSelection = scanner.nextInt();

            if (petSelection == 1) {
                pet = new Dog(petName);
                System.out.println("You chose a dog!");
            } else if (petSelection == 2) {
                pet = new Cat(petName);
                System.out.println("You chose a cat!");
            }
        }
        return userName;
    }

    public boolean gamePlay(String userName) {
        //Game begins:
        int actionsPerDay = 3;
        System.out.println("Please select a number (You have three actions per day): \n1. Feed \n2. Walk \n3. Pet \n4. Rest");

        while (actionsPerDay != 0) {

            System.out.print("Your choice: ");
            int userActionChoice = scanner.nextInt();

            switch (userActionChoice) {
                case 0:
                    return false;

                case 1:
                    pet.feed();
                    actionsPerDay--;
                    displayStats();

                    break;

                case 2:
                    pet.walk();
                    actionsPerDay--;
                    displayStats();

                    break;

                case 3:
                    pet.pet();
                    actionsPerDay--;
                    displayStats();

                    break;

                case 4:
                    pet.rest();
                    actionsPerDay--;
                    displayStats();

                    break;

                default:
                    System.out.println("Invalid option. Please choose again.");
                    break;

            }
            if (actionsPerDay == 0) {
                System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
                pet.sleep();
                System.out.println("A new day is dawning...");

                try {
                    TimeUnit.SECONDS.sleep(2);
                    System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
                } catch (InterruptedException ex) {
                    Logger.getLogger(VirtualPetApp.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Day: " + pet.getDayCount());
                displayStats();
            }
            if (pet.checkStats()) {
                System.out.println(pet.getName() + " ran away from home...");
                userlist.removeUser(userName);
                return false;

            }
            userlist.addUser(userName, pet);

        }
        return true;
    }

    public void action(String userName) {

        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Hello '" + userName + "'.");
        System.out.println("Your pet '" + pet.getName() + "' is *insert mood* to see you.");
        //Everytime a new user is created, it will store the pet name to that username and call it from file next time.
        ReadUserDataFile.writeToFile(userlist);

        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("What would you like to do with " + pet.getName() + " today?");
        boolean notDone = true;
        while (notDone) {
            notDone = gamePlay(userName);
        }
        System.out.println("\n\tThank you for playing");

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VirtualPetApp app = new VirtualPetApp();

        String userName = app.checkUser();
        app.action(userName);
        app.updataUser();

    }
    /*long timer = System.currentTimeMillis();
        long second = (timer / (1000 * 60));
        long minute = (timer / (1000 * 60)) % 60;
        long hour = (timer / (1000 * 60 * 60)) % 24;
        String time = String.format("%02d:%02d:%02d", hour, minute, second);*/
 /*Map<String,Integer> m = new  HashMap<String,Integer>();
        
        m.put("a", 1);
        m.put("b", 2);
        m.put("c", 3);
        m.put("d", 3);
        m.put("f", 3);
        
        for(Map.Entry<String,Integer> item : m.entrySet())
        System.out.println(item.getKey()+" "+item.getValue() );
     */

// public final static void clearConsole()
//{
//    try
//    {
//        final String os = System.getProperty("os.name");
//
//        if (os.contains("Windows"))
//        {
//            Runtime.getRuntime().exec("cls");
//        }
//        else
//        {
//            Runtime.getRuntime().exec("clear");
//        }
//    }
//    catch (final Exception e)
//    {
//        //  Handle any exceptions.
//    }
}
