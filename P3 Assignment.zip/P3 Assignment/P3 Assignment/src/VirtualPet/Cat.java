/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author Phaisan & Shannon
 */
public class Cat extends Animal implements Pet {

    public Cat(String name, int fullness, int energy, int excitment) {
        super(name, fullness, energy, excitment);
    }

    public Cat(String name) {
        super(name);
    }

   
    @Override
    public void feed() {
        this.fullness = this.fullness + 15 + getRandom(-4, 4);
        this.energy = this.energy + 5 + getRandom(-4, 4);
        this.excitement = this.excitement - 7 + getRandom(-4, 4);
    }

    @Override
    public void walk() {
        this.fullness = this.fullness + 15 + getRandom(-4, 4);
        this.energy = this.energy + 5 + getRandom(-4, 4);
        this.excitement = this.excitement - 7 + getRandom(-4, 4);

    }

    @Override
    public void rest() {
        this.fullness = this.fullness + 15 + getRandom(-4, 4);
        this.energy = this.energy + 5 + getRandom(-4, 4);
        this.excitement = this.excitement - 7 + getRandom(-4, 4);
    }

    @Override
    public void pet() {
        this.fullness = this.fullness + 15 + getRandom(-4, 4);
        this.energy = this.energy + 5 + getRandom(-4, 4);
        this.excitement = this.excitement - 7 + getRandom(-4, 4);
    }

    @Override
    public void sleep() {
        this.fullness = this.fullness + 15 + getRandom(-4, 4);
        this.energy = this.energy + 5 + getRandom(-4, 4);
        this.excitement = this.excitement - 7 + getRandom(-4, 4);
    }

}
