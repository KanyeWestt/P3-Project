/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author Phaisan & Shannon
 */
public interface Pet {

    public String getName();

    public int getFullness();

    public int getEnergy();

    public int getExcitement();

    public int getHealth();

    public void feed();

    public void walk();

    public void pet();

    public void sleep();

    public void rest();
    
    public int getDayCount();
    public void addDayCount();
    public boolean checkStats();
    

}
