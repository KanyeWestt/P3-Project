/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.Random;

/**
 *
 * @author gsj6766
 */
public abstract class Animal implements Pet {

    protected int fullness;
    protected int energy;
    protected int excitement;
    protected int happiness;
    protected String name;

    public Animal(String animalName, int fullness, int energy, int excitment) {
        setName(animalName);
        this.fullness = fullness;
        this.energy = energy;
        this.excitement = excitment;
    }

    public Animal(String animalName) {
        setName(animalName);
        this.fullness = 50;
        this.energy = 50;
        this.excitement = 50;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
    }

    @Override
    public int getFullness() {
        return fullness;
    }

    public void setFullness(int fullness) {
        this.fullness = fullness;
    }

    @Override
    public int getEnergy() {
        return energy;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }

    @Override
    public int getExcitement() {
        return excitement;
    }

    public void setExcitement(int excitement) {
        this.excitement = excitement;
    }

    @Override
    public int getHappiness() {
        return happiness;
    }

    public void setHappiness(int happiness) {
        this.happiness = happiness;
    }

    protected int getRandom(int x, int y) {
        return new Random().nextInt(y - x) + x;
    }

    @Override
    public String toString() {
        return name + " " + fullness + " " + energy + " " + excitement;
    }

}
