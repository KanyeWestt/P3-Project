/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author phaisan
 */
public class ReadUserDataFile {

    private final static String fileName = "user.txt";

    public static void ReadUserFile(User user) {
        try (Scanner fileScan = new Scanner(new FileInputStream(fileName))) {
            Pet pet;
            while (fileScan.hasNext()) {
                String line = fileScan.nextLine();
                StringTokenizer st = new StringTokenizer(line);

                String username = st.nextToken().trim().toLowerCase();
                String petType = st.nextToken().trim().toLowerCase();
                String petName = st.nextToken().trim().toLowerCase();
                int fullness = Integer.parseInt(st.nextToken());
                int energy = Integer.parseInt(st.nextToken());
                int excitment = Integer.parseInt(st.nextToken());

                switch (petType) {
                    case "dog":
                        pet = new Dog(petName, fullness, energy, excitment);
                        user.addUser(username, pet);
                    case "cat":
                        pet = new Cat(petName, fullness, energy, excitment);
                        user.addUser(username, pet);
                }

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReadUserDataFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void writeToFile(User user) {
        try (PrintWriter fileWriter = new PrintWriter(new FileOutputStream(fileName))) {
            for (Map.Entry<String, Pet> list : user.getUserList().entrySet()) {
                String userName = list.getKey();
                String petType = list.getValue().getClass().getName().toLowerCase();
                String pet = list.getValue().getName().toLowerCase();
                int fullness = list.getValue().getFullness();
                int energy = list.getValue().getEnergy();
                int excitment = list.getValue().getExcitement();
                fileWriter.println(userName + " " + petType + " " + pet);
            }

            fileWriter.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReadUserDataFile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
