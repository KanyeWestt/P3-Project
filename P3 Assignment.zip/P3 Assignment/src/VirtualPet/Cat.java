/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

/**
 *
 * @author phaisan
 */
public class Cat extends Animal implements Pet{
    
    public Cat(String name , int fullness,int energy,int excitment) {
        super(name,fullness,energy,excitment);
    }

    public Cat(String name) {
        super(name);
    }
    public void feed(){
        this.fullness = this.fullness +5;
        this.energy ++;
        this.excitement --;
    }
    public void walk() {
        this.fullness--;
        this.excitement ++;
        this.energy--;
        
    }
    public void rest(){
        this.fullness --;
        this.energy ++;
        this.excitement --;
    }
    
    public void pet(){
        this.fullness --;
        this.excitement++;
    }
    
    public void sleep(){
        this.fullness --;
        this.excitement --;
        this.energy ++;
    }
    
}
