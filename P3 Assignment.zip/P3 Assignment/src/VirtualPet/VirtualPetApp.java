/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author gsj6766
 */
public class VirtualPetApp {

    private User user;

    public VirtualPetApp(User user) {
        this.user = new User();
    }
    

    
     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pet p = new Dog("bob");
        User user= new User();

        ReadUserDataFile.ReadUserFile(user);

        user.addUser("neung", p);
        System.out.println(user.getUser("phaisan"));
        
        
        
        
        
        /*long timer = System.currentTimeMillis();
        long second = (timer / (1000 * 60));
        long minute = (timer / (1000 * 60)) % 60;
        long hour = (timer / (1000 * 60 * 60)) % 24;
        String time = String.format("%02d:%02d:%02d", hour, minute, second);*/
        
        /*Map<String,Integer> m = new  HashMap<String,Integer>();
        
        m.put("a", 1);
        m.put("b", 2);
        m.put("c", 3);
        m.put("d", 3);
        m.put("f", 3);
        
        for(Map.Entry<String,Integer> item : m.entrySet())
        System.out.println(item.getKey()+" "+item.getValue() );
        */

    }

}
