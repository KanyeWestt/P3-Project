/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.util.Random;

/**
 *This class allows multiple objects to be created and use its methods. We used cat and dog to extend this.
 * @author Phaisan & Shannon
 */
public abstract class Animal implements Pet {

    /**
     *
     */
    protected int fullness;

    /**
     *
     */
    protected int energy;

    /**
     *
     */
    protected int excitement;

    /**
     *
     */
    protected String name;

    /**
     *
     */
    protected String mood;

    /**
     *
     */
    protected int dayCount = 1;

    /**
     *
     * @param animalName
     * @param fullness
     * @param energy
     * @param excitment
     * @param dayCount
     */
    public Animal(String animalName, int fullness, int energy, int excitment , int dayCount) {
        setName(animalName);
        this.fullness = fullness;
        this.energy = energy;
        this.excitement = excitment;
        this.dayCount=dayCount;
    }

    /**
     *
     * @param animalName
     */
    public Animal(String animalName) {
        setName(animalName);
        this.fullness = 50;
        this.energy = 50;
        this.excitement = 50;
        this.dayCount = 1;
    }

    /**
     *
     * @return
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
    }

    /**
     *
     * @return
     */
    @Override
    public int getFullness() {
        return fullness;
    }

    /**
     *
     * @param fullness
     */
    public void setFullness(int fullness) {
        this.fullness = fullness;
    }

    /**
     *
     * @return
     */
    @Override
    public int getEnergy() {
        return energy;
    }

    /**
     *
     * @param energy
     */
    public void setEnergy(int energy) {
        this.energy = energy;
    }

    /**
     *
     * @return
     */
    @Override
    public int getExcitement() {
        return excitement;
    }

    /**
     *
     * @param excitement
     */
    public void setExcitement(int excitement) {
        this.excitement = excitement;
    }

    /**
     *
     * @return
     */
    @Override
    public int getDayCount() {
        return dayCount;
    }

    /**
     *
     */
    @Override
    public void addDayCount() {
        this.dayCount++;
    }
    
    /**
     *
     * @param x
     * @param y
     * @return
     */
    protected int getRandom(int x, int y) {
        return new Random().nextInt(y - x) + x;
    }
    
    /**
     *
     * @return
     */
    @Override
    public boolean checkStats(){
        return (this.excitement <15 || this.energy <25 || this.fullness < 20);
    
    }

    @Override
    public String toString() {
           return "["+this.name+"'s status:"+" Energy: "+this.energy+" Excitement: "+this.excitement+" Fullness: "+this.fullness;
    }


    

}
