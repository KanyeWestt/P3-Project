/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *This class reads the file saved from the user actions to allow the user to save their progress 
 * and continue from where they left off.
 * @author Phaisan & Shannon
 */
public class ReadUserDataFile {

    private final static String fileName = "user.txt";

    /**
     *This method will look for any saved file from previous users
     * @param userList
     */
    public static void ReadUserFile(User userList) {
        try (Scanner fileScan = new Scanner(new FileInputStream(fileName))) {
            Pet pet;
            while (fileScan.hasNext()) {
                String username = fileScan.nextLine().trim().toLowerCase();
                String petType = fileScan.nextLine().trim().toLowerCase();
                String petName = fileScan.nextLine().trim().toLowerCase();
                int fullness = Integer.parseInt(fileScan.nextLine());
                int energy = Integer.parseInt(fileScan.nextLine());
                int excitment = Integer.parseInt(fileScan.nextLine());
                int dayCount = Integer.parseInt(fileScan.nextLine());

                switch (petType) {
                    case "dog":
                        pet = new Dog(petName, fullness, energy, excitment, dayCount);
                        userList.addUser(username, pet);
                    case "cat":
                        pet = new Cat(petName, fullness, energy, excitment, dayCount);
                        userList.addUser(username, pet);
                }

            }
            fileScan.close();

        } catch (FileNotFoundException ex) {
            System.out.println(ex);
            Logger.getLogger(ReadUserDataFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *This method will write onto the file to save their progress in the game
     * @param userList
     */
    public static void writeToFile(User userList) {
        try (PrintWriter fileWriter = new PrintWriter(new FileOutputStream(fileName))) {
            userList.getUserList().entrySet().forEach((Map.Entry<String, Pet> list) -> {
                fileWriter.println(list.getKey());
                fileWriter.println(list.getValue().getClass().getSimpleName().toLowerCase());
                fileWriter.println(list.getValue().getName().toLowerCase());
                fileWriter.println(list.getValue().getFullness());
                fileWriter.println(list.getValue().getEnergy());
                fileWriter.println(list.getValue().getExcitement());
                fileWriter.println(list.getValue().getDayCount());

            });

            fileWriter.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReadUserDataFile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
