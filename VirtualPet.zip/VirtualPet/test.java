/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.*;

/**
 *
 * @author gsj6766
 */
public class test extends JFrame {

    public test() {

        JButton b1;
        JLabel l1;
        
        setTitle("Background Color for JFrame");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        setLayout(new BorderLayout());
        JLabel background = new JLabel(new ImageIcon("livingroom1.jpg"));
        add(background);
        background.setLayout(new FlowLayout());
        l1 = new JLabel("Here is a button");
        b1 = new JButton("I am a button");
        background.add(l1);
        background.add(b1);

    }
    
    public static void main (String[] args)
    {
        new test();
    }
}
