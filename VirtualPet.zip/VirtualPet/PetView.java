/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import Pet.Pet;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

/**
 *
 * @author Phaisan
 * @author Shannon Imbo - 1303744
 */
public class PetView extends JPanel implements Observer {


    // The user interface components needed by the controller
    private JButton feedButton;
    private JButton walkButton;
    private JButton petButton;
    private JButton restButton;
    private JButton helpButton;
    private JButton quitButton;
    private JTextField statsBoxField;
    private JTextField dialogueBox;

    public JButton getFeedButton() {
        return feedButton;
    }

    public JButton getWalkButton() {
        return walkButton;
    }

    public JButton getPetButton() {
        return petButton;
    }

    public JButton getRestButton() {
        return restButton;
    }
    
    public JButton getHelpButton() {
        return helpButton;
    }
    
    public JButton getQuitButton() {
        return quitButton;
    }

    public JTextField getStatsBoxField() {
        return statsBoxField;
    }

    public JTextField getDialgoueBoxField() {
        return dialogueBox;
    }

    public PetView(ItemList model) {
        
        setLayout(null);

        // Adds the text field for the status of the pet
        statsBoxField = new JTextField();
        statsBoxField.setEditable(false);
        statsBoxField.setLocation(20, 325);
        statsBoxField.setSize(100, 150);
        add(statsBoxField);

        // Adds the text field for dialogue
        dialogueBox = new JTextField();
        dialogueBox.setEditable(false);
        dialogueBox.setLocation(275, 545);
        dialogueBox.setSize(600, 70);
        add(dialogueBox);

        // Adds the Feed button
        feedButton = new JButton("Feed");
        feedButton.setLocation(20, 50);
        feedButton.setSize(100, 25);
        add(feedButton);

        // Adds the Walk button
        walkButton = new JButton("Walk");
        walkButton.setLocation(20, 120);
        walkButton.setSize(100, 25);
        add(walkButton);

        // Adds the Pet button
        petButton = new JButton("Pet");
        petButton.setLocation(20, 190);
        petButton.setSize(100, 25);
        add(petButton);

        // Adds the Rest button
        restButton = new JButton("Rest");
        restButton.setLocation(20, 260);
        restButton.setSize(100, 25);
        add(restButton);
        
        // Adds the Help button
        helpButton = new JButton("H");
        helpButton.setForeground(Color.RED);
        helpButton.setBackground(Color.WHITE);
        helpButton.setLocation(1100, 20);
        helpButton.setSize(45, 25);
        add(helpButton);
        
        // Adds the Exit button
        quitButton = new JButton("Q");
        quitButton.setForeground(Color.RED);
        quitButton.setBackground(Color.WHITE);
        quitButton.setLocation(1150, 20);
        quitButton.setSize(45, 25);
        add(quitButton);

        JPanel backgroundPanel = new JPanel();
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("room1.png"));
        backgroundPanel.add(new JLabel(backgroundImage), BorderLayout.CENTER);
        backgroundPanel.setSize(1222, 654);
        add(backgroundPanel);
        
        setSize(290, 230);
    }

    @Override
    public void update(Observable o, Object arg) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public JPanel createCat(Pet pet) {

        JPanel catPanel = new JPanel();
        pet.getClass().getSimpleName();
        String pic = "cat.jpg";
        ImageIcon catImage = new ImageIcon(getClass().getResource(pic));
        catPanel.add(new JLabel(catImage), BorderLayout.CENTER);
        catPanel.setSize(216, 189);
        catPanel.setLocation(490, 200);
        add(catPanel);

        return catPanel;
    }
    
    public JPanel createDog(Pet pet) {

        JPanel catPanel = new JPanel();
        pet.getClass().getSimpleName();
        String pic = "dog.jpg";
        ImageIcon catImage = new ImageIcon(getClass().getResource(pic));
        catPanel.add(new JLabel(catImage), BorderLayout.CENTER);
        catPanel.setSize(216, 189);
        catPanel.setLocation(490, 200);
        add(catPanel);

        return catPanel;
    }

}
