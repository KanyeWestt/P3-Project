/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualPet;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.*;

/**
 *
 * @author gsj6766
 */
public class MenuView extends JPanel {

    private JButton newGameButton;
    private JButton loadGameButton;
    private JButton chooseCatButton;
    private JButton chooseDogButton;
    private JButton startButton;
    private JButton choosePetButton;
    private JPanel loadGamePanel;
    private JPanel newGamePanel;
    private JTextField inputLoadUsername;
    private JTextField inputNewUsername;

    private JLabel title;

    public JButton getNewGameButton() {
        return newGameButton;
    }

    public JPanel getLoadGamePanel() {
        return loadGamePanel;
    }

    public JTextField getInputLoadUsername() {
        return inputLoadUsername;
    }

    public JButton getStartButton() {
        return startButton;
    }

    public JButton getnewGameButton() {
        return newGameButton;
    }

    public JButton getLoadGameButton() {
        return loadGameButton;
    }

    public JButton getChooseCatButton() {
        return chooseCatButton;
    }

    public JButton getChooseDogButton() {
        return chooseDogButton;
    }

    public JButton getChoosePetButton() {
        return choosePetButton;
    }

    public JPanel getNewGamePanel() {
        return newGamePanel;
    }

    public JTextField getInputNewUsername() {
        return inputNewUsername;
    }

    public JLabel getTitle() {
        return title;
    }

    public MenuView(ItemList model) {

        setLayout(null);

        title = new JLabel("PET OWNER SIMULATOR");
        title.setFont(new Font("Arial", Font.BOLD, 35));
        title.setLocation(375, 100);
        title.setSize(600, 200);
        add(title);

        newGameButton = new JButton("New Game!");
        newGameButton.setFont(new Font("Arial", Font.BOLD, 25));
        newGameButton.setLocation(500, 250);
        newGameButton.setSize(200, 100);
        add(newGameButton);

        loadGameButton = new JButton("Load game...");
        loadGameButton.setFont(new Font("Arial", Font.BOLD, 25));
        loadGameButton.setLocation(500, 400);
        loadGameButton.setSize(200, 100);
        add(loadGameButton);

        JPanel menuPanel = new JPanel();
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("menu.jpg"));
        menuPanel.add(new JLabel(backgroundImage), BorderLayout.CENTER);
        menuPanel.setSize(1222, 654);
        add(menuPanel);
    }

    public JPanel loadGame() {
        JPanel loadGamePanel = new JPanel();

        JTextField inputLoadUsername = new JTextField("Enter User name");
        inputLoadUsername.setFont(new Font("Arial", Font.BOLD, 35));
        inputLoadUsername.setLocation(375, 100);
        inputLoadUsername.setSize(600, 200);

        JButton startButton = new JButton("start");
        startButton.setFont(new Font("Arial", Font.BOLD, 25));
        startButton.setLocation(500, 250);
        startButton.setSize(200, 100);
        add(startButton);

        loadGamePanel.add(inputLoadUsername);
        loadGamePanel.add(startButton);

        clearScreen();

        return loadGamePanel;

    }

    public JPanel newGame() {

        JPanel newGamePanel = new JPanel();

        JTextField inputNewUsername = new JTextField("Enter User name");
        inputNewUsername.setFont(new Font("Arial", Font.BOLD, 35));
        inputNewUsername.setLocation(375, 100);
        inputNewUsername.setSize(600, 200);

        JButton choosePetButton = new JButton("choose pet");
        choosePetButton.setFont(new Font("Arial", Font.BOLD, 25));
        choosePetButton.setLocation(500, 250);
        choosePetButton.setSize(200, 100);
        add(choosePetButton);

        newGamePanel.add(inputNewUsername);
        newGamePanel.add(choosePetButton);

        clearScreen();

        return newGamePanel;

    }

    private JPanel choosePet() {

        JPanel newGamePanel = new JPanel();

        JButton chooseCatButton = new JButton("choose a cat");
        chooseCatButton.setFont(new Font("Arial", Font.BOLD, 25));
        chooseCatButton.setLocation(350, 250);
        chooseCatButton.setSize(200, 100);
        add(chooseCatButton);

        JButton chooseDogButton = new JButton("choose a dog");
        chooseDogButton.setFont(new Font("Arial", Font.BOLD, 25));
        chooseDogButton.setLocation(750, 250);
        chooseDogButton.setSize(200, 100);
        add(chooseDogButton);

        newGamePanel.add(chooseDogButton);
        newGamePanel.add(chooseCatButton);

        clearScreen();

        return newGamePanel;

    }

    public void clearScreen() {
        removeAll();

        JPanel menuPanel = new JPanel();
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("menu.jpg"));
        menuPanel.add(new JLabel(backgroundImage), BorderLayout.CENTER);
        menuPanel.setSize(1222, 654);
        add(menuPanel);
    }

}
